/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author UNIVALLE
 */
public class EquipoComputo {

    // Atributos
    private int numeroEquipo;
    private String marca;
    private String capacidadDD;

    public EquipoComputo() {
    }

    public int getNumeroEquipo() {
        return numeroEquipo;
    }

    public void setNumeroEquipo(int numeroEquipo) {
        this.numeroEquipo = numeroEquipo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getCapacidadDD() {
        return capacidadDD;
    }

    public void setCapacidadDD(String capacidadDD) {
        this.capacidadDD = capacidadDD;
    }



    
}
