package principal;

import controlador.ControlReservaGUI;

public class Principal {

    public static void main(String[] args) {
        ControlReservaGUI principal = new ControlReservaGUI();

    }

}
